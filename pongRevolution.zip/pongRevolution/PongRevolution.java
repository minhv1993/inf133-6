package pongRevolution;

public class PongRevolution {

	private class Pong {
		int vX = 0;
		int vY = 0;
		int ballX;
		int ballY;
		double friction = 0.998f;
	}
}
